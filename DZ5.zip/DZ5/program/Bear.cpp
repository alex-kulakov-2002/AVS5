#include <iostream>
#include "Bear.h"

void Bear::start() {
    while (true) {
        if (!Bear::beehive->try_to_steal_honey()){
            std::this_thread::sleep_for(std::chrono::seconds(Bear::time_for_healing));
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }
}

Bear::Bear(Beehive *beehive1, int time_for_healing)  {
    Bear::beehive = beehive1;
    Bear::time_for_healing = time_for_healing;
}