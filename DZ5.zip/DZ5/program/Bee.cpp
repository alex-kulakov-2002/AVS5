#include <iostream>
#include "Bee.h"

void Bee::start() {
    while(true){
        if ((double)rand() / RAND_MAX > 0.3){
            if (Bee::isInBeehive){
                beehive->bee_leave();
                isInBeehive = false;
            }

            std::this_thread::sleep_for(std::chrono::seconds(Bee::time_for_collecting_honey));
            beehive->bee_come();
            isInBeehive = true;
            beehive->add_honey();
        }
        else{
            if (!Bee::isInBeehive) beehive->bee_come();
            Bee::isInBeehive = true;
            std::this_thread::sleep_for(std::chrono::seconds(Bee::time_for_collecting_honey));
        }
    }
}

Bee::Bee(Beehive *beehive1, int time_for_collecting_honey)  {
    isInBeehive = true;
    Bee::beehive = beehive1;
    Bee::time_for_collecting_honey = time_for_collecting_honey;
}