#include <iostream>
#include "Beehive.h"
#include "mutex"

void Beehive::add_honey() {
    mtx.lock();
    if (Beehive::number_of_honey < 30) {
        Beehive::number_of_honey++;
        std::cout << "Пчела принесла мед, стало: "  <<  number_of_honey << " каплей меда " << "Seconds: " << ((double)(clock() - time_start)) / CLOCKS_PER_SEC  << '\n';
    }
    std::this_thread::sleep_for(std::chrono::milliseconds(1));
    mtx.unlock();
}

bool Beehive::try_to_steal_honey() {
    while(number_of_honey < 15){

    }
    mtx.lock();
    if (Beehive::bee_in_beehive < 3) {
        Beehive::number_of_honey = 0;
        Beehive::number_of_steal++;
        std::cout << "Медведь своровал мед " << "Seconds: " << ((double)(clock() - time_start)) / CLOCKS_PER_SEC << '\n';
        mtx.unlock();
        return true;
    } else {
        std::cout << "Медведя покусали " << "Seconds: " << ((double)(clock() - time_start)) / CLOCKS_PER_SEC  << '\n';
        mtx.unlock();
        return false;
    }
}

void Beehive::start(int number_of_bee, int time_bee_to_collect_honey, int time_bear_healing){
    bee_in_beehive = number_of_bee;
    for (int i = 0; i< number_of_bee; i++){
        Bee bee(this, time_bee_to_collect_honey);
        std::thread t(&Bee::start, bee);
        t.detach();
    }
    Bear bear(this, time_bear_healing);
    std::thread t(&Bear::start, bear);
    t.detach();
    while(this->number_of_steal < 10){

    }
}

void Beehive::bee_come() {
    std::lock_guard<std::mutex> guard(Beehive::mtx);
    Beehive::bee_in_beehive++;
}

void Beehive::bee_leave() {
    std::lock_guard<std::mutex> guard(Beehive::mtx);
    Beehive::bee_in_beehive--;
}

Beehive::Beehive() {
    clock_t time_start = clock();
    Beehive::mtx.unlock();
    Beehive::bee_in_beehive = 0;
    Beehive::number_of_honey = 0;
    Beehive::number_of_steal = 0;
}