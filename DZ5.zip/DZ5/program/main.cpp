#include <iostream>
#include <ctime>
#include <cstring>
#include "Beehive.h"
#include "thread"
#include "time.h"

void number_of_arguments_error(){
    std::cout << "Некорректное число аргументов";
}

void not_correct_first_argument_error(){
    std::cout << "Некорректный первый аргумент";
}

void type_of_arguments_error(){
    std::cout << "Некорректный тип аргументов";
}

void number_of_bees_error(){
    std::cout << "Некорректное число пчел, их должно быть от 4 до 30";
}

void time_to_collect_honey_error(){
    std::cout << "Некорректное время затрачиваемое на сбор 1 единицы меда пчелой";
}

void time_to_healing_bear_error(){
    std::cout << "Некорректное время на лечение медведя";
}

int main(int argc, char* argv[]) {
    clock_t time_start = clock();
    srand(time(NULL));
    int time_to_haeling_bear = 0;
    int number_of_bees = 0;
    int time_to_collect_honey = 0;
    if (argc < 2){
        number_of_arguments_error();
        exit(1);
    }
    if (strcmp(argv[1], "-r") != 0 && strcmp(argv[1], "-i") != 0){
        not_correct_first_argument_error();
        exit(1);
    }
    if(strcmp(argv[1], "-r") == 0){
        if (argc != 2){
            number_of_arguments_error();
            exit(1);
        }
        time_to_haeling_bear = rand() % 100 + 1;
        time_to_collect_honey = rand() % 100 + 1;
        number_of_bees = rand() % 27 + 4;
    }
    else {
        if (argc != 5) {
            number_of_arguments_error();
            exit(1);
        }
        try {
            number_of_bees = std::stoi(argv[2]);
        }
        catch (std::invalid_argument e) {
            type_of_arguments_error();
            exit(1);
        }
        if (number_of_bees < 4 || number_of_bees > 30) {
            number_of_bees_error();
            exit(1);
        }
        try {
            time_to_collect_honey = std::stoi(argv[3]);
        }
        catch (std::invalid_argument e) {
            type_of_arguments_error();
            exit(1);
        }
        if (time_to_collect_honey < 1 || time_to_collect_honey > 100) {
            time_to_collect_honey_error();
            exit(1);
        }
        try {
            time_to_haeling_bear = std::stoi(argv[4]);
        }
        catch (std::invalid_argument e) {
            type_of_arguments_error();
            exit(1);
        }
        if (time_to_haeling_bear < 1 || time_to_haeling_bear > 100) {
            time_to_healing_bear_error();
            exit(1);
        }
    }
    std::cout << "Количество пчел: " << number_of_bees << '\n';
    std::cout << "Время сбора меда и время сидения в улее: " << time_to_collect_honey << '\n';
    std::cout << "Время излечивания медведя: " << time_to_haeling_bear;
    std::cout << '\n';
    auto* beehive = new Beehive();
    beehive->start(number_of_bees, time_to_collect_honey, time_to_haeling_bear);
    std::cout << "Seconds: " << ((double)(clock() - time_start)) / CLOCKS_PER_SEC;
    return 0;
}
